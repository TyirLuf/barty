# Ionic Core V6 Datetime: IonAccordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/mhartington/pen/XWzewGo](https://codepen.io/mhartington/pen/XWzewGo).

