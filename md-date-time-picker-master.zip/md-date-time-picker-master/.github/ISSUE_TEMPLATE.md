# Issue Templates

- Search the currently opened issues and past issues before posting a new one.
- Escalate issues by making a reaction of :+1: at the first comment on the issue (the issue author's)
- Be clear and try to open an issue with one problem at a time (open multiple issues if you have multiple problems)
