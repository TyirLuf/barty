# Contributing to md-date-time-picker

There are a number of ways you can help by Contributing to this project, Here are some:

- Improve the docs and point out suggestions / improvements
- Send pull requests if you can fix a bug.
- Always be polite in your approach.
