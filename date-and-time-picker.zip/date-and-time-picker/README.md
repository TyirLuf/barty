# Date and Time Picker

A Pen created on CodePen.io. Original URL: [https://codepen.io/jaromvogel/pen/aNPRwG](https://codepen.io/jaromvogel/pen/aNPRwG).

Date and time picker directive