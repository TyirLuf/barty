COMO RODAR O PROJETO BAIXADO
Necessário ter o Composer instalado na máquina, para verificar se está instalado corretamente
### composer -v

Instalar todas as dependencias indicada pelo package.json
### composer install


SEQUENCIA PARA CRIAR O PROJETO
Necessário ter o Composer instalado na máquina, para verificar se está instalado corretamente
### composer -v

Criar o arquivo composer.json
### composer init

Baixar a biblioteca utilizando Composer para gerar PDF 
### composer require dompdf/dompdf