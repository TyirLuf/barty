<?php

// Usar o use para carregar classe através do Composer
use chillerlan\QRCode\{QRCode, QROptions};

// Incluir Composer
include_once('./vendor/autoload.php');

// Criar a variável com a URL para o QRCode
$data = 'https://celke.com.br/curso/curso-de-php';

// Instanciar a classe para enviar os parâmetros para o QRCode
$options = new QROptions([
    // Número da versão do código QRCode
    'version'      => 7,
    // Tipo de saída, utilizado SVG
    'outputType'   => QRCode::OUTPUT_FPDF,
    // Define o nível de correção de erro
    'eccLevel'     => QRCode::ECC_L,
    // escala da imagem 
    'scale'        => 4,
    // Alterar para base64
    'imageBase64'  => false,
]);

// Função header() é usada para enviar um cabeçalho HTTP, o cabeçalho HTTP fornece informações sobre tipo de dados 'pdf' que será enviado no corpo da mensagem
header('Content-type: application/pdf');

// Gerar QRCode: instanciar a classe QRCode e enviar os dados para o render gerar o QRCode
$qrcode = (new QRCode($options))->render($data);
//var_dump($qrcode);

// Gerar PDF com o QRCode
echo $qrcode;