# Ionic Core V6 Datetime: no changes

A Pen created on CodePen.io. Original URL: [https://codepen.io/mhartington/pen/KKyXLQX](https://codepen.io/mhartington/pen/KKyXLQX).

