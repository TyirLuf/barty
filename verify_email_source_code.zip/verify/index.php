<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
</head>
<body>

	<h1>Home page</h1>

	<?php include('header.php')?>
	
</body>
</html>