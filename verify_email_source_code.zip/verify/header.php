<div>
	<a href="index.php">Home</a> . <a href="login.php">Login</a> . <a href="signup.php">Signup</a> . <a href="profile.php">Profile</a> . <a href="logout.php">Logout</a> . 
</div>