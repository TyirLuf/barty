<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Celke - Gerar PDF com imagem</title>
</head>
<body>

    <h1>Como gerar PDF com PHP</h1>

    <a href="gerar_pdf.php">Gerar PDF</a>
    
</body>
</html>